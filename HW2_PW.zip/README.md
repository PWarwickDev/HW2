GUI I
HW2: Style a Site with External CSS
Paul Warwick
Student ID: 01902962
Student Email: paul_warwick@student.uml.edu

Project Description: Used CSS to style a page that fits the images provided.

General Structure: Index.html is styled by pacific.css.

I did not change file structure as then I would need to update the html file(which was not allowed).



Requirement Fulfillment:

    - My website is very close to the given images, besides maybe color differences in some areas.
    - I believe this project fulfills all requirements.

Website Link: https://pwarwickdev.github.io/HW2/

Github Repo: https://github.com/PWarwickDev/HW2
